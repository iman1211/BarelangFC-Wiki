Lua script to access CM board in terminal mode:
lua cm_terminal.lua

Lua script to download firmware to CM board
lua bootloader.lua firmware_file
and press reset on board.

