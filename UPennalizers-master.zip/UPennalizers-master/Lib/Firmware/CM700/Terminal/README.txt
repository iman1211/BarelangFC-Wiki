Lua script to access CM700 in terminal mode:
lua cm700_terminal.lua

Lua script to download firmware to CM700
lua bootloader.lua firmware_file
and press reset on board.

