int lua_field_spots(lua_State *L);
