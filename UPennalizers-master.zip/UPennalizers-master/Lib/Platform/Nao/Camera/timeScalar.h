#ifndef timeScalar_h_DEFINED
#define timeScalar_h_DEFINED

#ifdef __cplusplus
extern "C" {
#endif

  double time_scalar();

#ifdef __cplusplus
}
#endif

#endif

