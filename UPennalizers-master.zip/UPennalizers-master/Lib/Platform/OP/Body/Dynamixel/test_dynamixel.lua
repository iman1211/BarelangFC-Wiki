require('Dynamixel');

twait = 0.010;

Dynamixel.open();
Dynamixel.ping_probe();
