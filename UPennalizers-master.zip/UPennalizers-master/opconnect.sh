#!/bin/sh

echo "Connecting darwin"
ssh -X -C darwin@192.168.123.$1
